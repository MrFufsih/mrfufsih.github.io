# C++ 类与对象基础(上)

C++ 是 C 语言的拓展，许多特性（如**类**）正是为了解决 C 语言在大型项目中缺乏封装性、安全性等问题而设计的。  
本文涵盖以下核心知识点：
- 类的定义
- 访问限定符（`public` / `private` / `protected`）
- 类的实例化与内存布局
- `this` 指针的作用与原理

---

## 一、类的定义

类（`class`）是 C++ 面向对象编程的核心，用于将**数据**（成员变量）和**操作**（成员函数）封装在一起。

### 基本语法

```cpp
class Stack {
public:
    void Init(int capacity = 4) {
        arr = (int*)malloc(sizeof(int) * capacity);
        if (arr == nullptr) return;
        size = capacity;
        top = 0;
    }

    void Push(int val) {
        if (top < size) {
            arr[top++] = val;
        }
    }

    void Destroy() {
        free(arr);
        arr = nullptr;
        top = size = 0;
    }

private:
    int* arr;
    int size;
    int top;
};
```

- `class` 是定义类的关键字，`Stack` 是类名。
- `{}` 内为**类体**，包含：
  - **成员变量**（如 `arr`, `size`, `top`）
  - **成员函数**（如 `Init`, `Push`, `Destroy`）

> 💡 `struct` 和 `class` 在 C++ 中几乎完全相同，**唯一区别是默认访问权限**：
> - `class` 默认为 `private`
> - `struct` 默认为 `public`

---

## 二、访问限定符

访问限定符控制类成员在**类外是否可访问**：

| 限定符     | 类内 | 类外 | 继承 |
|------------|------|------|------|
| `public`   | ✅   | ✅   | ✅   |
| `private`  | ✅   | ❌   | ❌   |
| `protected`| ✅   | ❌   | ✅   |

### 使用规则

1. 从某个限定符开始，直到下一个限定符或类结束，其作用域持续生效。
2. 可重复使用多个限定符。
3. **最佳实践**：
   - 成员变量 → `private`（封装数据）
   - 成员函数 → `public`（提供接口）

```cpp
class Person {
public:
    void SetName(const string& name) { this->name = name; }
    void Print() { cout << "Name: " << name << endl; }

private:
    string name;
    int age = 0;
};
```

---

## 三、类域（Class Scope）

类定义了一个独立的作用域（**类域**）。若在类外定义成员函数，必须使用 `::` 指明所属类。

```cpp
class Calculator {
public:
    void Add(int a, int b); // 声明
    void PrintResult();

private:
    int result = 0;
};

// 类外定义：必须用 :: 指定作用域
void Calculator::Add(int a, int b) {
    result = a + b;
}

void Calculator::PrintResult() {
    cout << "Result: " << result << endl;
}
```

> ❌ 若省略 `Calculator::`，编译器会将其视为**全局函数**，导致链接错误。

---

## 四、实例化（Instantiation）

### 什么是实例化？

将类的抽象描述转化为**具体对象**的过程，称为**实例化**。

- **类**：像“图纸”——只声明成员，不分配内存。
- **对象**：像“产品”——实例化时为每个成员变量分配独立内存。

```cpp
class Point {
public:
    double x, y;
};

int main() {
    Point p1; // 实例化对象 p1
    Point p2; // 实例化对象 p2
    return 0;
}
```

> ⚠️ 类定义时**不会分配内存**；只有创建对象时才会为成员变量分配空间。

---

## 五、对象的内存布局与对齐

### 成员函数不占对象内存

- 所有对象**共享同一份成员函数代码**（存储在代码段）。
- 对象内存中**只包含成员变量**。

### 内存对齐规则

1. 结构体/类的对齐值 = 其所有成员中**最大对齐值**。
2. 成员之间可能插入**填充字节**，确保每个成员按其对齐要求存放。
3. 总大小向上对齐到对齐值的整数倍（保证数组中元素对齐）。

> 📌 Visual Studio 默认对齐为 **8 字节**。  
> 内存对齐是“**以空间换时间**”的优化策略。

示例：
```cpp
class Example {
    char a;    // 1 byte → 对齐到 1
    int b;     // 4 bytes → 对齐到 4
    short c;   // 2 bytes → 对齐到 2
};
// sizeof(Example) = 12 (1 + 3 padding + 4 + 2 + 2 padding)
```

---

## 六、`this` 指针

### 问题引入

成员函数如何知道操作的是哪个对象？

```cpp
Point p1, p2;
p1.SetX(10);
p2.SetX(20);
// 编译器如何区分 p1 和 p2？
```

### `this` 指针的原理

- C++ 编译器会为**每个非静态成员函数**隐式添加一个参数：`ClassName* const this`
- 调用时自动传入对象地址

```cpp
// 你写的代码
void Point::SetX(double x) {
    this->x = x; // 等价于 x = x;（需用 this 区分）
}

// 编译器实际处理为
void SetX(Point* const this, double x) {
    this->x = x;
}
```

### 使用场景

- 解决成员变量与参数同名冲突
- 支持链式调用（返回 `*this`）

```cpp
class Counter {
    int value = 0;
public:
    Counter& Add(int n) {
        value += n;
        return *this; // 返回当前对象引用
    }
    void Print() { cout << value << endl; }
};

// 链式调用
Counter c;
c.Add(5).Add(3).Print(); // 输出 8
```

> ⚠️ `this` 是**隐式参数**，不能在函数声明/定义中显式写出，但可在函数体内使用。

---

## 总结

| 概念 | 作用 |
|------|------|
| **类** | 封装数据与行为的蓝图 |
| **访问限定符** | 控制成员可见性，实现信息隐藏 |
| **实例化** | 创建具体对象，分配内存 |
| **内存对齐** | 优化 CPU 访问效率 |
| **`this` 指针** | 隐式指向当前对象，实现成员函数与对象绑定 |

> 🌟 **类是 C++ 面向对象的基石**。理解其定义、封装机制、内存模型及 `this` 指针的工作原理，是掌握 C++ OOP 的关键第一步。