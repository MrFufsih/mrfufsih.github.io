// /blog/article-loader.js

// 1. 配置 marked + highlight.js
marked.setOptions({
  highlight: (code, lang) => {
    const language = hljs.getLanguage(lang) ? lang : 'plaintext';
    return hljs.highlight(code, { language }).value;
  },
  langPrefix: 'hljs language-',
  breaks: true,
  gfm: true
});

// 2. 获取 Markdown 路径
function getMarkdownPath() {
  const meta = document.querySelector('meta[name="article-source"]');
  if (meta && meta.content) return meta.content;

  const path = window.location.pathname;
  const filename = path.split('/').pop().replace(/\.html$/, '');
  return `/1/articles/${filename}.md`;
}

// 3. 加载侧边栏
fetch('/sidebar.html')
  .then(res => res.text())
  .then(html => {
    document.getElementById('dynamic-sidebar').innerHTML = html;
  })
  .catch(() => {
    document.getElementById('dynamic-sidebar').innerHTML =
      '<div style="padding:20px;color:var(--text-secondary);">⚠️ 侧边栏加载失败</div>';
  });

// 4. 主题管理
const bgMap = {
  light: '/public/background-light.jpg',
  dark: '/public/background-dark.jpg'
};
const overlay = document.querySelector('.overlay');
const htmlEl = document.documentElement;
const toggleBtn = document.getElementById('theme-toggle');

const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
const userPreference = localStorage.getItem('theme');
let currentTheme = userPreference || (systemPrefersDark ? 'dark' : 'light');

function applyTheme(theme) {
  htmlEl.setAttribute('data-theme', theme);
  overlay.style.backgroundImage = `url('${bgMap[theme]}')`;
  toggleBtn.textContent = theme === 'light' ? '🌙 深色模式' : '☀️ 浅色模式';
}

applyTheme(currentTheme);

toggleBtn.addEventListener('click', () => {
  currentTheme = currentTheme === 'light' ? 'dark' : 'light';
  localStorage.setItem('theme', currentTheme);
  applyTheme(currentTheme);
});

window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
  if (!localStorage.getItem('theme')) {
    currentTheme = e.matches ? 'dark' : 'light';
    applyTheme(currentTheme);
  }
});

// 5. 渲染文章
document.addEventListener('DOMContentLoaded', async () => {
  try {
    const mdPath = getMarkdownPath();
    const res = await fetch(mdPath);
    if (!res.ok) throw new Error(`文章未找到 (${res.status})`);

    const mdText = await res.text();
    const titleMatch = mdText.match(/^#\s+(.+)$/m);
    const title = titleMatch ? titleMatch[1].trim() : '无标题';

    document.title = `${title} | 小伏鱼的博客`;
    document.querySelector('.article-title').textContent = title;
    document.getElementById('article-content').innerHTML = marked.parse(mdText);

    document.querySelectorAll('pre code').forEach(hljs.highlightElement);
  } catch (err) {
    console.error('文章加载失败:', err);
    document.getElementById('article-content').innerHTML = `
      <p style="color: var(--error-color); text-align:center;">
        ❌ ${err.message}<br>
        <small>请检查 Markdown 文件路径是否正确</small>
      </p>
    `;
  }
});