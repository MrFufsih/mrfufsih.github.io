# C++ 类与对象基础(中)

在上一节中，我们学习了类的基本定义与 `this` 指针。本节将深入探讨 C++ 面向对象编程中最核心的部分——**类的六个默认成员函数**：

- 构造函数（Constructor）
- 析构函数（Destructor）
- 拷贝构造函数（Copy Constructor）
- 赋值运算符重载（Copy Assignment Operator）
- 取地址运算符重载（Address-of Operator）
- const 取地址运算符重载

> 💡 这六个函数由编译器在需要时**自动合成**，但当类管理资源（如动态内存、文件句柄等）时，必须**显式定义**以避免浅拷贝、重复释放等问题。

---

## 一、构造函数（Constructor）

### 作用
在对象**创建时自动调用**，用于初始化成员变量。

### 特点
1. 函数名与类名相同。
2. 无返回值（连 `void` 也不写）。
3. 支持重载。
4. 若用户未定义任何构造函数，编译器会生成一个**无参默认构造函数**；一旦用户定义了任意构造函数，编译器**不再生成**。
5. **默认构造函数**包括：
   - 无参构造函数
   - 全缺省构造函数
   - 编译器自动生成的构造函数  
   > ⚠️ 三者只能存在其一，否则调用时会产生歧义。

6. 编译器生成的构造函数：
   - **内置类型**（如 `int`, `double`）：**不初始化**（值随机）
   - **自定义类型**：调用其默认构造函数

### 示例：日期类

```cpp
#include <iostream>
using namespace std;

class Date {
public:
    // 无参构造函数
    Date() : _year(0), _month(0), _day(0) {}

    // 有参构造函数
    Date(int year, int month, int day)
        : _year(year), _month(month), _day(day) {}

private:
    int _year;
    int _month;
    int _day;
};

int main() {
    Date d1;               // 调用无参构造
    Date d2(2024, 8, 20);  // 调用有参构造
    // Date d3();       // ❌ 这是函数声明！不是对象定义
    return 0;
}
```

---

## 二、析构函数（Destructor）

### 作用
在对象**销毁时自动调用**，用于释放资源（如 `free`、关闭文件等）。

### 特点
1. 函数名为 `~类名`。
2. 无参数、无返回值。
3. 一个类**只能有一个**析构函数。
4. 若未定义，编译器会生成默认析构函数：
   - **内置类型**：不做任何事
   - **自定义类型**：调用其析构函数
5. 局部对象按**定义顺序的逆序**析构。

### 示例：栈类（管理动态内存）

```cpp
typedef int STDataType;

class Stack {
public:
    Stack(int n = 4) {
        _data = (STDataType*)malloc(sizeof(STDataType) * n);
        if (!_data) { perror("malloc failed"); return; }
        _capacity = n;
        _top = 0;
    }

    ~Stack() {
        free(_data);
        _data = nullptr;
        _top = _capacity = 0;
    }

private:
    STDataType* _data;
    int _top;
    int _capacity;
};
```

> ✅ 对于 `Date` 类（无资源），可依赖默认析构；对于 `Stack`，**必须自定义析构**！

---

## 三、拷贝构造函数（Copy Constructor）

### 定义
第一个参数为**自身类类型的常量引用**的构造函数。

```cpp
ClassName(const ClassName& other);
```

### 为什么必须是引用？
若传值：`ClassName(ClassName other)` → 会再次调用拷贝构造 → **无限递归**！

### 调用场景
- 用一个对象初始化另一个对象：`Date d2(d1);`
- 值传递传参：`void func(Date d); func(d1);`
- 值返回：`Date get(); Date d = get();`

### 编译器默认行为
- **内置类型**：逐字节拷贝（浅拷贝）
- **自定义类型**：调用其拷贝构造

> ⚠️ 对于含指针的类（如 `Stack`），**浅拷贝会导致多个对象共享同一块内存**，析构时重复 `free` → **程序崩溃**！

### 正确实现：深拷贝

```cpp
// 拷贝构造函数（深拷贝）
Stack(const Stack& s) {
    _data = (STDataType*)malloc(sizeof(STDataType) * s._capacity);
    if (!_data) { perror("malloc failed"); return; }
    memcpy(_data, s._data, sizeof(STDataType) * s._top);
    _top = s._top;
    _capacity = s._capacity;
}
```

### 示例对比

```cpp
Date d1(2024, 8, 20);
Date d2(d1);      // 调用拷贝构造（浅拷贝 OK）
Date d3 = d1;     // 等价于 Date d3(d1);

Stack s1;
s1.Push(1); s1.Push(2);
Stack s2(s1);     // 必须深拷贝，否则析构崩溃
```

---

## 四、赋值运算符重载（Copy Assignment Operator）

### 与拷贝构造的区别
|                | 拷贝构造                     | 赋值运算符重载             |
|----------------|------------------------------|----------------------------|
| **对象状态**   | 目标对象**未创建**           | 两个对象**均已存在**       |
| **调用时机**   | 初始化时                     | 已存在对象之间赋值         |

### 特点
1. 必须是**成员函数**
2. 返回 `*this` 的引用，支持链式赋值：`a = b = c;`
3. 需处理**自赋值**（`a = a`）
4. 默认行为同拷贝构造（浅拷贝）

### 实现示例

```cpp
Stack& operator=(const Stack& s) {
    if (this != &s) { // 防止自赋值
        free(_data);  // 释放原资源
        _data = (STDataType*)malloc(sizeof(STDataType) * s._capacity);
        if (!_data) { perror("malloc failed"); return *this; }
        memcpy(_data, s._data, sizeof(STDataType) * s._top);
        _top = s._top;
        _capacity = s._capacity;
    }
    return *this;
}
```

---

## 五、取地址运算符重载

C++ 默认提供两个取地址运算符重载：

```cpp
T* operator&();              // 普通版本
const T* operator&() const;  // const 对象版本
```

### 一般无需重载
除非你想**禁止获取对象地址**或返回特殊指针：

```cpp
class Date {
public:
    // 禁止取地址
    Date* operator&() { return nullptr; }
    const Date* operator&() const { return nullptr; }
};
```

> 📌 实际开发中极少需要重载此运算符。

---

## 六、const 成员函数

在成员函数后加 `const`，表示该函数**不会修改对象状态**：

```cpp
void Print() const {
    cout << _year << "-" << _month << "-" << _day << endl;
}
```

### 底层原理
`const` 修饰的是 `this` 指针：
```cpp
void Print() const;
// 等价于
void Print(const Date* const this);
```

### 规则
- `const` 对象**只能调用** `const` 成员函数
- 非 `const` 对象可调用任意成员函数

---

## 总结：何时需要自定义默认成员函数？

| 类类型         | 是否需要自定义？ | 原因                     |
|----------------|------------------|--------------------------|
| **仅含内置类型**（如 `Date`） | ❌ 否            | 默认行为足够             |
| **管理资源**（如 `Stack`）   | ✅ 是            | 需要深拷贝、资源释放     |

> 🔑 **Rule of Three / Five**：  
> 如果你需要自定义**析构函数**，通常也需要自定义**拷贝构造**和**赋值运算符**（C++11 后还包括移动构造和移动赋值）。

---

> 🌟 掌握这六大默认成员函数，是编写安全、高效 C++ 类的基础。理解“浅拷贝 vs 深拷贝”、“构造 vs 赋值”、“资源管理”等核心概念，才能真正驾驭 C++ 面向对象编程。