# C++ 核心特性详解

本文涵盖以下 C++ 核心知识点：
- 命名空间（Namespace）
- C++ 输入输出（I/O）
- 缺省参数（Default Arguments）
- 函数重载（Function Overloading）
- 引用（Reference）与 const 引用
- 内联函数（Inline Function）
- `nullptr` 的引入

---

## 一、命名空间（Namespace）

为解决大型项目中变量、函数、类的**命名冲突**，C++ 引入了命名空间。它将标识符封装在独立作用域中，避免全局污染。

### 基本定义与访问

```cpp
namespace fish {
    int rand = 10;
    int ADD(int a, int b) {
        return a + b;
    }
    struct node {
        struct node* next;
        int val;
    };
}
```

访问方式：使用作用域解析符 `::`

```cpp
cout << fish::rand << endl;          // 输出 10
cout << fish::ADD(2, 3) << endl;     // 输出 5
```

### 嵌套命名空间

```cpp
namespace fish {
    namespace bigfish {
        int rand = 1;
    }
}
```

访问嵌套空间：

```cpp
cout << fish::bigfish::rand << endl; // 输出 1
```

### 使用 `using` 展开命名空间

```cpp
#include <iostream>
using namespace std;
using namespace fish; // 展开后可直接使用 ADD

int main() {
    cout << ADD(1, 2) << endl; // 无需 fish::
    return 0;
}
```

> ⚠️ 注意：`using namespace std;` 在大型项目中应谨慎使用，避免污染全局命名空间。

---

## 二、C++ 输入输出（I/O）

需包含头文件 `<iostream>`，使用标准流对象：

- `std::cin`：标准输入（键盘）
- `std::cout`：标准输出（屏幕）
- `std::endl`：插入换行并刷新缓冲区

```cpp
#include <iostream>
using namespace std;

int main() {
    int age;
    cout << "请输入年龄: ";
    cin >> age;
    cout << "你的年龄是: " << age << endl;
    return 0;
}
```

✅ 优势：**无需格式符**（如 `%d`），自动类型推导。

---

## 三、缺省参数（Default Arguments）

在函数声明或定义中为参数提供默认值。调用时若未传参，则使用默认值。

### 规则
- 必须**从右向左连续**设置缺省值
- 声明与定义**不能同时**提供缺省值

```cpp
#include <iostream>
using namespace std;

int add(int a = 1, int b = 2) {
    return a + b;
}

int main() {
    cout << "全缺省: " << add() << endl;        // 3
    cout << "半缺省: " << add(5) << endl;       // 7 (a=5, b=2)
    cout << "无缺省: " << add(3, 4) << endl;    // 7
    return 0;
}
```

❌ 错误示例：
```cpp
// add(, 4); // 语法错误！不能跳过左侧参数
```

---

## 四、函数重载（Function Overloading）

允许**同名函数**存在，通过**参数类型、个数或顺序不同**进行区分。

### 1. 参数类型不同

```cpp
void swap(int& x, int& y) { /* ... */ }
void swap(char& x, char& y) { /* ... */ }
```

### 2. 参数个数不同

```cpp
int add(int x, int y) { return x + y; }
int add(int x, int y, int z) { return x + y + z; }
```

### ❌ 不能仅靠返回值重载

```cpp
// void fun();   // ❌ 编译错误！
// int fun();    // 无法区分调用
```

---

## 五、引用（Reference）

引用是**已有变量的别名**，与原变量共享同一内存地址。

### 基本用法

```cpp
int a = 10;
int& b = a; // b 是 a 的别名
b = 20;     // 等价于 a = 20
```

### 特性
1. 必须初始化
2. 不能更改引用对象
3. 一个变量可有多个引用

```cpp
int a = 0;
int& b = a;
int& c = a;
cout << &a << " " << &b << " " << &c << endl; // 地址相同
```

### 引用 vs 指针

| 特性 | 引用 | 指针 |
|------|------|------|
| 初始化 | 必须 | 可选 |
| 可变性 | 不能重新绑定 | 可指向不同对象 |
| 内存 | 别名（无额外空间） | 存储地址（占内存） |

### 应用：简化指针操作（如链表）

```cpp
struct Node {
    int data;
    Node* next;
};

void push(Node*& head, int val) {
    Node* newNode = new Node{val, head};
    head = newNode;
}
```

使用 `Node*&` 避免了二级指针，代码更简洁。

---

## 六、const 引用

用于绑定**常量或临时对象**，遵循“权限不能放大”原则。

```cpp
int a = 1;
const int& ref1 = a;      // OK：普通变量 → const 引用
const int& ref2 = 10;     // OK：字面量（临时对象）
const int& ref3 = a * 3;  // OK：表达式结果（临时对象）

// int& ref4 = 3.14;      // ❌ 错误！临时对象具有常性
const int& ref5 = 3.14;   // ✅ 正确
```

---

## 七、内联函数（Inline Function）

用 `inline` 修饰的函数，在编译时**展开调用**，减少函数调用开销。

```cpp
inline int Add(int x, int y) {
    return x + y + 3;
}

int main() {
    int ret = Add(1, 2); // 编译器可能直接替换为 1+2+3
    return 0;
}
```

> 💡 适用于**短小、频繁调用**的函数。编译器有权忽略 `inline`。

---

## 八、`nullptr` —— 更安全的空指针

### 问题：`NULL` 的歧义

在 C++ 中，`NULL` 通常是 `0`（整数），导致重载冲突：

```cpp
void fun(int x) { cout << "int\n"; }
void fun(int* x) { cout << "pointer\n"; }

fun(NULL); // 调用 fun(int)，而非预期的指针版本！
```

### 解决方案：使用 `nullptr`

```cpp
fun(nullptr); // 明确调用 fun(int*)
```

✅ `nullptr` 是**指针类型字面量**，不会与整数混淆。

---

> 📌 **总结**：C++ 通过命名空间、引用、重载等机制，在保持 C 高效的同时，增强了类型安全与开发体验。合理使用这些特性，可写出更健壮、可维护的代码。