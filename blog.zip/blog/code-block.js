// code-block.js
// 博客代码块增强：高亮 + 复制 + 主题同步（VS Code 风格）

(function () {
  'use strict';

  // === 1. 初始化主题 ===
  function getPreferredTheme() {
    const saved = localStorage.getItem('theme');
    if (saved) return saved;
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  }

  function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);

    // 切换 Highlight.js 样式
    let hlStyle = document.querySelector('link[data-hl-style]');
    if (hlStyle) hlStyle.remove();

    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.dataset.hlStyle = 'true'; // 标记以便后续移除

    // vs2015 是深色主题，浅色用 github 更协调
    if (theme === 'dark') {
      link.href = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/vs2015.min.css';
    } else {
      link.href = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/github.min.css';
    }

    document.head.appendChild(link);

    // 更新按钮文字
    const toggleBtn = document.getElementById('theme-toggle');
    if (toggleBtn) {
      toggleBtn.textContent = theme === 'dark' ? '☀️ 浅色模式' : '🌙 深色模式';
    }
  }

  // === 2. 复制代码功能 ===
  function copyCode(button) {
    const codeBlock = button.closest('.code-block');
    const codeElement = codeBlock.querySelector('pre code');
    const codeText = codeElement.innerText;

    navigator.clipboard.writeText(codeText).then(() => {
      const originalText = button.textContent;
      button.textContent = '✅ 已复制';
      setTimeout(() => {
        button.textContent = originalText;
      }, 1500);
    }).catch(err => {
      console.warn('复制失败:', err);
      button.textContent = '⚠️ 失败';
      setTimeout(() => {
        button.textContent = originalText;
      }, 1500);
    });
  }

  // === 3. 绑定事件 ===
  function bindEvents() {
    // 主题切换
    const toggleBtn = document.getElementById('theme-toggle');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme') || 'light';
        setTheme(current === 'dark' ? 'light' : 'dark');
      });
    }

    // 所有复制按钮
    document.querySelectorAll('.copy-btn').forEach(btn => {
      btn.addEventListener('click', function () {
        copyCode(this);
      });
    });
  }

  // === 4. 初始化 ===
  function init() {
    // 设置初始主题
    const initialTheme = getPreferredTheme();
    setTheme(initialTheme);

    // 等待 DOM 和 Highlight.js 加载完成后再高亮
    if (typeof hljs !== 'undefined') {
      hljs.highlightAll();
    } else {
      // 如果 hljs 还没加载，等它加载完再高亮
      window.addEventListener('hljs-loaded', () => {
        hljs.highlightAll();
      });
    }

    // 绑定交互
    bindEvents();
  }

  // 如果 Highlight.js 已加载，立即初始化；否则等待
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();