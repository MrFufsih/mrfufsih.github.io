// /public/shared.js

// ========== 1. 加载侧边栏 ==========
function loadSidebar() {
  const sidebarEl = document.getElementById('dynamic-sidebar');
  if (!sidebarEl) return;

  // 自动推断 sidebar 路径（根据页面深度）
  const depth = window.location.pathname.split('/').filter(Boolean).length - 1;
  const sidebarPath = '../'.repeat(depth || 1) + 'sidebar.html';

  fetch(sidebarPath)
    .then(res => res.text())
    .then(html => {
      sidebarEl.innerHTML = html;
    })
    .catch(err => {
      console.warn('⚠️ 侧边栏加载失败:', err);
      sidebarEl.innerHTML = '<div style="padding:20px;color:var(--text-secondary);">侧边栏加载失败</div>';
    });
}

// ========== 2. 主题管理 ==========
function initTheme() {
  const bgMap = {
    light: '/public/background-light.jpg',
    dark: '/public/background-dark.jpg'
  };

  const overlay = document.querySelector('.overlay');
  const htmlEl = document.documentElement;
  const toggleBtn = document.getElementById('theme-toggle');

  if (!toggleBtn || !overlay) return;

  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const userPreference = localStorage.getItem('theme');
  let currentTheme = userPreference || (systemPrefersDark ? 'dark' : 'light');

  function applyTheme(theme) {
    htmlEl.setAttribute('data-theme', theme);
    overlay.style.backgroundImage = `url('${bgMap[theme]}')`;
    toggleBtn.textContent = theme === 'light' ? '🌙 深色模式' : '☀️ 浅色模式';
  }

  applyTheme(currentTheme);

  toggleBtn.addEventListener('click', () => {
    currentTheme = currentTheme === 'light' ? 'dark' : 'light';
    localStorage.setItem('theme', currentTheme);
    applyTheme(currentTheme);
  });

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (!localStorage.getItem('theme')) {
      currentTheme = e.matches ? 'dark' : 'light';
      applyTheme(currentTheme);
    }
  });
}

// ========== 3. 自动初始化 ==========
document.addEventListener('DOMContentLoaded', () => {
  loadSidebar();
  initTheme();
});