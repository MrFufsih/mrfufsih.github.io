# C++ 类与对象（下）

在前三节中，我们系统学习了类的基础定义、六大默认成员函数等核心内容。本节将完成“类与对象”主题的收尾，涵盖以下高级特性：

- 构造函数深入：初始化列表
- 隐式类型转换与 `explicit`
- `static` 静态成员
- 友元（`friend`）
- 内部类
- 匿名对象

---

## 一、构造函数深入：初始化列表

除了在构造函数体内赋值，C++ 提供更高效、更安全的**初始化方式**——**初始化列表**。

### 语法格式

```cpp
ClassName(参数列表)
    : 成员1(初值), 成员2(初值), ...
{
    // 函数体
}
```

### 示例

```cpp
class Time {
public:
    Time(int h) : hour(h) {
        cout << "Time(int)" << endl;
    }
private:
    int hour;
};
```

### 初始化列表的注意事项

1. **每个成员只能出现一次**（初始化仅发生一次）。
2. 以下三类成员**必须**在初始化列表中初始化：
   - 引用成员（如 `int& ref;`）
   - `const` 成员（如 `const int x;`）
   - 没有默认构造函数的自定义类型成员
3. 成员可在**声明处提供缺省值**，用于未在初始化列表中显式初始化的情况。
4. **初始化顺序由成员在类中的声明顺序决定**，与初始化列表书写顺序无关！

### ⚠️ 经典陷阱示例

```cpp
class Fun {
public:
    Fun(int a) : a1(a), a2(a1) {} // 看似 a2 = a1，实则危险！

    void print() { cout << a1 << " " << a2 << endl; }

private:
    int a2 = 1; // 声明顺序：a2 在 a1 之前！
    int a1 = 1;
};

int main() {
    Fun x(2);
    x.print(); // 输出：2 和 一个随机值！
}
```

> 🔍 原因：`a2` 先于 `a1` 初始化，此时 `a1` 尚未被赋值（值未定义），导致 `a2` 被随机值初始化。

✅ **建议**：始终按成员声明顺序书写初始化列表，或调整成员声明顺序以匹配逻辑依赖。

---

## 二、类型转换

### 隐式类型转换

C++ 允许通过**单参数构造函数**实现从内置类型到类类型的隐式转换。

```cpp
class Fun {
public:
    Fun(int a) : a1(a) {}
private:
    int a1;
};

int main() {
    Fun f = 10; // 隐式转换：10 → Fun(10)
    return 0;
}
```

### 禁止隐式转换：`explicit`

在构造函数前加 `explicit`，禁止编译器自动转换：

```cpp
explicit Fun(int a) : a1(a) {}

// Fun f = 10;      // ❌ 编译错误！
Fun f(10);          // ✅ 显式调用 OK
```

> 💡 **最佳实践**：除非明确需要隐式转换（如智能指针），否则对单参构造函数使用 `explicit`。

---

## 三、`static` 静态成员

### 静态成员变量

- 属于**整个类**，而非某个对象。
- 所有对象共享同一份数据。
- **必须在类外定义并初始化**（不能在声明处给缺省值）。

### 静态成员函数

- 没有 `this` 指针。
- 只能访问**静态成员**（不能访问非静态成员变量/函数）。
- 可通过 `类名::函数名()` 调用。

### 示例：统计对象创建次数

```cpp
#include <iostream>
using namespace std;

class Counter {
public:
    Counter(int val) : value(val) {
        count++; // 静态成员计数
    }

    static void PrintCount() {
        cout << "Total objects: " << count << endl;
    }

private:
    int value;
    static int count; // 声明
};

// 类外定义并初始化
int Counter::count = 0;

int main() {
    Counter c1(1), c2(2);
    Counter::PrintCount(); // 输出：Total objects: 2
    return 0;
}
```

> 📌 静态成员不受访问限定符影响其“共享性”，但仍受 `public/private` 控制访问权限。

---

## 四、友元（`friend`）

友元机制允许**非成员函数或其它类**访问当前类的 `private`/`protected` 成员。

### 友元函数

```cpp
class Date {
    friend void PrintDate(const Date& d); // 声明友元函数
private:
    int year, month, day;
};

void PrintDate(const Date& d) {
    cout << d.year << "-" << d.month << "-" << d.day << endl; // 可访问私有成员
}
```

### 友元类

```cpp
class Engine {
    friend class Car; // Car 是 Engine 的友元
private:
    int power = 200;
};

class Car {
public:
    void ShowPower(const Engine& e) {
        cout << e.power << " HP"; // OK：Car 可访问 Engine 的私有成员
    }
};
```

### 注意事项
- 友元关系是**单向的**（A 是 B 的友元 ≠ B 是 A 的友元）
- 友元关系**不可传递**
- **破坏封装性**，应谨慎使用（常用于运算符重载、序列化等场景）

---

## 五、内部类

在一个类内部定义的类，称为**内部类**。

### 特性
- 内部类**默认是外部类的友元**，可访问其所有成员（包括 `private`）。
- 外部类**不是**内部类的友元。
- 内部类是独立的类型，可通过 `外部类::内部类` 访问。

### 示例

```cpp
class Outer {
public:
    Outer(int x) : data(x) {}

    class Inner {
    public:
        void AccessOuter(const Outer& o) {
            cout << o.data << endl; // 可访问外部类的 private 成员
        }
    };

private:
    int data;
};

int main() {
    Outer o(42);
    Outer::Inner inner;
    inner.AccessOuter(o); // 输出：42
    return 0;
}
```

> 💡 若将内部类放在 `private` 区域，则只能在外部类内部使用（“专属内部类”）。

---

## 六、匿名对象

**匿名对象**：没有名字的对象，生命周期仅限于**当前语句**。

### 语法

```cpp
ClassName(参数);
```

### 用途

1. **临时调用成员函数**（尤其静态上下文）

```cpp
class Logger {
public:
    Logger() { count++; }
    static void ShowCount() { cout << count << endl; }
private:
    static int count;
};
int Logger::count = 0;

int main() {
    Logger();           // 创建并立即销毁
    Logger().ShowCount(); // 匿名对象调用静态函数（无需命名）
    return 0;
}
```

2. **简化代码**（如工厂模式返回临时对象）
3. **避免命名污染**

> ⚠️ 匿名对象在语句结束时自动析构，不可取地址、不可赋值。

---

## 总结

| 特性 | 作用 | 使用建议 |
|------|------|--------|
| **初始化列表** | 高效初始化成员 | 优先使用，注意声明顺序 |
| **`explicit`** | 禁止隐式转换 | 单参构造函数默认加 `explicit` |
| **`static`** | 类级别共享数据/函数 | 用于计数器、工具函数等 |
| **友元** | 突破封装限制 | 谨慎使用，避免滥用 |
| **内部类** | 逻辑封装 + 友元访问 | 适用于紧密耦合的辅助类 |
| **匿名对象** | 临时操作 | 用于一次性调用或简化代码 |

> 🌟 至此，“C++ 类与对象”系列圆满结束。掌握这些特性，你已具备编写健壮、高效、面向对象 C++ 代码的能力！下一步可深入学习继承、多态、模板等高级主题。