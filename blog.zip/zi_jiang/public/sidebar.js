// sidebar.js

function initSidebar(root) {
  // 设置头像
  const avatar = document.getElementById('sidebar-avatar');
  if (avatar) {
    avatar.src = root + 'public/head.jpg';
    avatar.onerror = () => { avatar.style.display = 'none'; };
  }

  // 生成分类按钮
  const categories = [
    { name: '学习', path: 'blog/learning/index.html' },
    { name: '生活', path: 'blog/life/index.html' },
    { name: '项目', path: 'blog/projects/index.html' },
    { name: '随笔', path: 'blog/essays/index.html' }
  ];

  const container = document.getElementById('sidebar-links');
  if (container) {
    container.innerHTML = ''; // 清空（防止重复）
    categories.forEach(cat => {
      const a = document.createElement('a');
      a.href = root + cat.path;
      a.className = 'category-btn';
      a.textContent = cat.name;
      container.appendChild(a);
    });
  }
}

document.addEventListener('DOMContentLoaded', function() {
  // 根据当前页面计算 SITE_ROOT
  let rootPrefix = '';

  if (window.location.protocol === 'file:') {
    const parts = window.location.pathname.split('/').filter(p => p.length > 0);
    const depth = parts.length;
    rootPrefix = depth <= 2 ? './' : '../'.repeat(depth - 2);
  } else {
    const urlParts = new URL(window.location.href).pathname.split('/').filter(p => p);
    rootPrefix = urlParts.length === 0 ? './' : '../'.repeat(urlParts.length);
  }

  // 初始化侧边栏
  initSidebar(rootPrefix);
});